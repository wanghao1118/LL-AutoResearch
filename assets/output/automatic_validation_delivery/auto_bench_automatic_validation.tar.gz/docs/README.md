# Auto-Bench 对接说明

## 1. 当前结论

本分支 `add/auto-bench` 已把主流程从“生成页面等待研究者选择 Match/Partial/Mismatch”迁移为“盲匹配结束后自动读取论文证据并核对”。用户不再需要下载、填写或上传 `literature_audit_submission*.json`。

当前机器流程可运行，44 项测试通过；最新权威 fresh suite 仍暴露质量缺口，所以状态是：

```text
AUTOMATED_LITERATURE_VALIDATION_NEEDS_ITERATION
```

这不是执行失败。它表示自动核对已经完成，而且最新未见论文结果中仍有 `PARTIAL` 和 `MISMATCH`。反馈优化后 Suite 003 从 `0 MATCH / 4 PARTIAL / 1 MISMATCH` 提升到 `3 MATCH / 2 PARTIAL / 0 MISMATCH`，但反馈集不能当作泛化结果。

## 2. 当前执行链

```mermaid
flowchart TD
  A["匿名 Introduction + Method"] --> B["gold-free worker"]
  B --> C["benchmark_plan.json"]
  C --> D["worker 退出并封存"]
  D --> E["读取论文 Experiment benchmark 证据"]
  E --> F["step3 定量评估"]
  F --> G["auto-review 逐论文核对"]
  G --> H{"决策"}
  H -->|MATCH| I["保留结果"]
  H -->|PARTIAL 或 MISMATCH| J["生成 typed feedback"]
  J --> K["修改通用画像、排序或 route 规则"]
  K --> L["feedback regression"]
  L --> M["下一套 fresh holdout"]
```

主流程输出里保留 `human_submission_required: false`。`BenchmarkPlan.human_review` 仅作为旧 schema 的兼容字段，固定状态为 `NOT_REQUIRED`。

## 3. 代码与职责

| 文件 | 当前职责 |
|---|---|
| `autobench/profile_agent.py` | 从 Introduction/Method 提取任务族、模态、交互、输出、环境、能力、指标和显式 suite 广度 |
| `autobench/match_agent.py` | 多维打分、coverage-first 排序、specialization gate、portfolio 选择 |
| `autobench/pipeline.py` | 生成 plan 和 `automatic_review_input.json` |
| `autobench/workflow.py` | 执行 direct/adaptation/synthesis route，写 manifest 与 deterministic verification |
| `autobench/synthesis_agent.py` | 生成 provenance-preserving draft，并设置 `automatic_validation_status` |
| `autobench/auto_literature_review.py` | 自动比较论文 benchmark 证据与 matcher 结果，输出决策和 typed errors |
| `autobench/cli.py` | `match`、`run`、`synthesize`、`auto-review`；旧 `review` 命令只保留兼容性 |
| `step2_run_blind_matching.py` | 在临时 gold-free sandbox 执行每个 case |
| `step3_evaluate_blind_results.py` | post-run 读取 gold，计算 recall、MRR、precision、route 与逐论文证据 |
| `step15_audit_completion.py` | 汇总机器检查、最新 fresh 自动核对和与其配对的 feedback regression |
| `step29_freeze_fresh_suite003_matcher.py` | 在 Suite 003 前冻结 matcher 文件尺寸与 catalog ID |
| `step30_select_fresh_suite003_papers.py` | 只按公开 title/abstract 选择 Suite 003 论文 |
| `step31_fetch_fresh_suite003_sources.py` | 下载官方论文 source |
| `step32_build_fresh_suite003_cases.py` | 只抽取并匿名化 Introduction/Method |
| `step33_run_fresh_suite003_blind.py` | 运行 Suite 003 sealed blind workers |
| `step34_build_fresh_suite003_gold.py` | worker 退出后从论文实验内容构建 gold evidence |

## 4. 关键产物

### 权威 fresh 结果

- `assets/output/fresh_holdout_suite_003/evaluation.json`
- `assets/output/automatic_literature_review/fresh_holdout_suite_003.json`
- `assets/output/fresh_holdout_suite_003/pre_gold_run_record.json`

### 当前反馈优化结果

- `assets/output/fresh_holdout_suite_003/development_after_feedback_v3/`
- `assets/output/fresh_holdout_suite_003/development_after_feedback_v3_evaluation.json`
- `assets/output/automatic_literature_review/fresh_holdout_suite_003_feedback_v3.json`

### 仓库总状态

- `assets/output/end_to_end_demo/completion_audit.json`
- `assets/output/end_to_end_demo/completion_audit.md`

### 自动进度可视化

- `assets/output/automatic_literature_review/auto_bench_progress.html`

## 5. 当前数据

| Suite | 阶段 | Recall@5 | Recall@6 | MRR | Selected modeled recall | Selected actual precision | Route accuracy | MATCH / PARTIAL / MISMATCH |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| 001 | fresh baseline | 0.5000 | 0.5000 | 0.3187 | 0.2500 | 0.0667 | 0.2000 | 0 / 1 / 4 |
| 001 | feedback v1 | 0.9000 | 0.9000 | 0.6500 | 0.6500 | 0.4667 | 1.0000 | 3 / 2 / 0 |
| 002 | fresh baseline | 0.9333 | 0.9333 | 0.3000 | 0.9333 | 0.3333 | 0.0000 | 0 / 2 / 3 |
| 002 | feedback v2 | 0.9333 | 0.9333 | 0.4000 | 0.9333 | 0.4000 | 1.0000 | 4 / 1 / 0 |
| 003 | fresh baseline | 0.6333 | 0.7333 | 0.4125 | 0.6333 | 0.3000 | 0.4000 | 0 / 4 / 1 |
| 003 | feedback v3 | 1.0000 | 1.0000 | 0.6000 | 0.9000 | 0.5000 | 1.0000 | 3 / 2 / 0 |

严格 evaluator 的 precision 会把“论文使用了 catalog 外 benchmark，而系统选择一个合理 base benchmark 进入 adaptation”计为 extra。因此 completion audit 同时保留数值指标和自动论文构造核对，不能只看一个 precision 数字。

## 6. 实验推进历程

### Round 1 — 从 Auto-Search 分支切到 Auto-Bench

1. **设计动机：** 原仓库主要是 Auto-Search；本分支需要独立实现论文 Method 到 benchmark 的工作流。
2. **具体方案与关键参数：** 在 `add/auto-bench` 上清理旧工作树，以 `configs/benchmark_catalog.json` 和 typed dataclass 为核心重建；Python 入口统一使用 `python3`。
3. **结果数据：** 建立 Introduction/Method 输入 schema、benchmark catalog、CLI 和基础测试。
4. **核心发现/失败原因：** 只输出单个 benchmark 不能覆盖跨任务论文；必须输出 portfolio、指标和 route。
5. **下一步洞察：** 用 task-family coverage 和多维 compatibility score 代替单一关键词检索。

### Round 2 — 盲匹配与泄漏隔离

1. **设计动机：** 若 matcher 看到论文身份或 benchmark 名称，检索准确率没有意义。
2. **具体方案与关键参数：** 每个 worker 使用独立临时目录，只复制 package、公开 catalog 和一个匿名 case；扫描 benchmark alias；Top-5、Top-6、MRR、selected recall、precision 和 route accuracy 全部记录。
3. **结果数据：** 初始三篇论文的所有 worker 均正常退出，leakage checks 通过，matcher 未加载 hidden labels。
4. **核心发现/失败原因：** 全局分数排序容易被同一任务的相似 benchmark 占满，跨任务 coverage 不稳定。
5. **下一步洞察：** 先覆盖任务族，再执行 task-balanced triangulation 和 specialization gate。

### Round 3 — 三类 route 与可执行 synthesis

1. **设计动机：** catalog 不可能覆盖所有创新 Method；缺少 benchmark 时仍需给出可执行路径。
2. **具体方案与关键参数：** route 分为 `direct_portfolio`、`base_benchmark_adaptation`、`new_benchmark_synthesis`；synthesis 只接受 train/development records；实现 interaction wrapper、compositional recombination、counterfactual perturbation。
3. **结果数据：** 三类 demo 均生成 manifest；有源数据的 synthesis 模块 deterministic verification 全部 `PASS`。
4. **核心发现/失败原因：** 用测试集作为 synthesis seed 会污染评测；只写 draft 不验证 source gold 也不够。
5. **下一步洞察：** 强制 source split、record ID、expected output 与 transformation provenance，并在 workflow 中自动复核。

### Round 4 — 历史人工 literature audit

1. **设计动机：** 早期需要确认 matcher 推荐是否等同于论文真实 benchmark。
2. **具体方案与关键参数：** 生成 source-revealed HTML，让研究者逐 case 选择 Match/Partial/Mismatch；submission 绑定 audit ID 和 scope snapshot。
3. **结果数据：** 完成多轮 main、holdout 001 和 holdout 002 的人工记录，并保留历史 verdict。
4. **核心发现/失败原因：** 人工步骤重复、慢，而且在同一批论文上反复反馈后容易把回归结果误当泛化结果。
5. **下一步洞察：** 保留历史模块用于复现，将新主流程改为 sealed matcher 后的自动 source comparison。

### Round 5 — Fresh Suite 001 与自动 evaluator 原型

1. **设计动机：** 需要在未参与规则设计的论文上检查任务画像和 route 泛化。
2. **具体方案与关键参数：** 5 篇 fresh 论文；先保存 baseline，再按揭示 gold 修正规则；自动 evaluator 输出 6 类 typed error。
3. **结果数据：** baseline Recall@5/6 为 `0.5000/0.5000`，route accuracy `0.2000`，自动判定 `0/1/4`；feedback v1 提升到 Recall@5/6 `0.9000/0.9000`、route `1.0000`、判定 `3/2/0`。
4. **核心发现/失败原因：** 初始规则对新领域任务族识别不足；feedback 能修复已见论文，但不能证明泛化。
5. **下一步洞察：** 每轮必须区分 `fresh_holdout` 和 `feedback_regression`，completion 只由最新 fresh 结果决定。

### Round 6 — Fresh Suite 002 与评测广度推断

1. **设计动机：** 检查 Suite 001 修复是否能迁移到程序辅助推理、工具增强 NLP、机器人、经典规划和视觉程序组合。
2. **具体方案与关键参数：** 冻结 matcher 后选择 5 篇论文；从 Introduction/Method 提取声明的评测数量；catalog 外任务进入 `uncovered_task_families`；portfolio 上限根据可见 suite breadth 扩展。
3. **结果数据：** baseline Recall@5/6 `0.9333/0.9333`，route accuracy `0.0000`，自动判定 `0/2/3`；feedback v2 route 提升到 `1.0000`，自动判定 `4/1/0`。
4. **核心发现/失败原因：** 纯 benchmark recall 很高仍可能 route 全错；ReWOO 的一个具体 benchmark 不能由 Introduction/Method 唯一恢复。
5. **下一步洞察：** route 与 catalog 外任务族恢复必须成为自动核对的一等条件，不能只优化 Recall@K。

### Round 7 — Fresh Suite 003 与多域失败暴露

1. **设计动机：** 在 v2 后再做真正未见论文验证，避免被 Suite 002 feedback 的高分误导。
2. **具体方案与关键参数：** 冻结 21 个 matcher 文件和 26 个 catalog IDs；选取 Toolformer、ProgPrompt、Visual Programming、Program of Thoughts、Tree of Thoughts；每个 worker 只接收 Introduction/Method。
3. **结果数据：** baseline Recall@5 `0.6333`、Recall@6 `0.7333`、MRR `0.4125`、route `0.4000`，自动判定 `0/4/1`。
4. **核心发现/失败原因：** 缺失工具增强语言任务、机器人 manipulation、图像编辑、金融数值 QA、creative writing 和 word puzzle；Toolformer、PoT、ToT route 错误。Suite 选择与 matcher 已先冻结，但协调进程在 blind run 前的宏观 inventory 中曾打印部分 Experiment 行；worker 隔离未受影响，因此该 caveat 已写入 `pre_gold_run_record.json`。
5. **下一步洞察：** 下一套 fresh suite 除了 worker 隔离，还要禁止协调进程在 blind completion 前输出任何 Experiment 文本。

### Round 8 — Suite 003 feedback v3

1. **设计动机：** 把 Suite 003 自动核对暴露的错误转成通用规则，而不是手工写死 benchmark 名称。
2. **具体方案与关键参数：** 新增 `tool_augmented_nlp`、`language_modeling`、`robot_manipulation`、`image_editing`、`financial_numerical_qa`、`creative_writing`、`word_puzzle`；解析同一评测句中的总 breadth；允许 mixed task portfolio 在显式 breadth 下跨环境补充 benchmark。
3. **结果数据：** Recall@5/6 `1.0000/1.0000`，selected modeled recall `0.9000`，route `1.0000`，自动判定 `3/2/0`。
4. **核心发现/失败原因：** Toolformer 仍有 SVAMP 与 GSM8K 的具体选择歧义；ProgPrompt 的 VirtualHome 与 ALFWorld 仍有环境粒度差异。两项都属于可见文本不足或 catalog 粒度问题。
5. **下一步洞察：** 下一轮需要更明确地区分“任务构造匹配”与“复现论文具体 benchmark 名称”，并在 catalog 中加入环境 family 层级。

### Round 9 — 移除主流程人工门禁并修复回归

1. **设计动机：** 用户明确要求后续不再参与人工 Match/Partial/Mismatch，系统自行对照论文并继续优化。
2. **具体方案与关键参数：** 新增 `auto-review` CLI；plan 状态改为 `AUTOMATIC_LITERATURE_CHECK_PENDING`；workflow 只写 `automatic_review_input.json`；synthesis 使用 `automatic_validation_status`；completion audit 只读取 `AUTO_LITERATURE_EVALUATOR` 产物，并把最新 fresh suite 与同 suite feedback 配对。
3. **结果数据：** 44/44 tests 通过；Suite 002 v2 重放仍为 `4/1/0`；Suite 003 v3 重放仍为 `3/2/0`；completion audit 的 `human_submission_required=false`、`human_gates=[]`。
4. **核心发现/失败原因：** v3 的背景任务过滤曾导致 ReAct 的 symbolic reasoning 误触发、LATS 的 programming 漏检、CRITIC 的 mathematical program synthesis 被误判为 code generation；已用上下文 precedence 和更窄的 image/audio 模态规则修复。另一个 completion bug 会把 `main_regression.json` 当作最新 feedback，已改为按 fresh suite 序号配对。
5. **下一步洞察：** 创建 Suite 004 前先冻结 v3 matcher，并把 meta-agent 的 Experiment 输出也纳入 blind protocol；fresh 全部 `MATCH` 后再把状态置为 `COMPLETE`。

## 7. 复现实验

### 完整测试

```bash
python3 -m compileall -q autobench step15_audit_completion.py tests/test_autobench.py
python3 -m unittest tests.test_autobench
```

### 重放 Suite 003 feedback v3

```bash
python3 step2_run_blind_matching.py \
  --cases-dir assets/input/fresh_holdout_suite_003/cases \
  --case-pattern 'fresh3_*.json' \
  --output-dir assets/output/fresh_holdout_suite_003/development_after_feedback_v3

python3 step3_evaluate_blind_results.py \
  --runs-dir assets/output/fresh_holdout_suite_003/development_after_feedback_v3 \
  --gold-dir assets/input/fresh_holdout_suite_003/gold \
  --matcher-cases-dir assets/input/fresh_holdout_suite_003/cases \
  --output assets/output/fresh_holdout_suite_003/development_after_feedback_v3_evaluation.json \
  --report assets/output/fresh_holdout_suite_003/development_after_feedback_v3_evaluation.md \
  --minimum-cases 5

python3 -m autobench auto-review \
  --evaluation assets/output/fresh_holdout_suite_003/development_after_feedback_v3_evaluation.json \
  --output-json assets/output/automatic_literature_review/fresh_holdout_suite_003_feedback_v3.json \
  --output-markdown assets/output/automatic_literature_review/fresh_holdout_suite_003_feedback_v3.md \
  --evidence-class feedback_regression
```

严格 evaluator 当前返回 `NEEDS_ITERATION`，所以第二条命令退出码为 `1`；产物仍完整有效，自动核对命令继续运行。

## 8. 下一步执行计划

1. 生成 Suite 004 freeze manifest，记录 matcher 文件尺寸、catalog ID 集合和分支状态；
2. 只用 title/abstract 选择至少 5 篇新论文；
3. 匿名化 Introduction/Method，不在协调日志显示 Experiment；
4. 运行 sealed workers 并验证所有 exit status 为 0；
5. 之后构建 gold evidence；
6. 自动输出 fresh review；
7. 若存在 `PARTIAL` 或 `MISMATCH`，按 typed error 修改通用规则并进入 v4 feedback；
8. 不向用户发出人工评测请求。
