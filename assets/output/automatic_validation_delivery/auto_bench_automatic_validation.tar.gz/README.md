# Auto-Bench

Auto-Bench 将论文的 **Introduction + Method** 映射为 benchmark 组合、评测指标与三类执行路径。盲匹配 worker 看不到论文标题、作者、实验章节、benchmark 名称和隐藏 gold。worker 退出后，独立 evaluator 才读取论文中的 benchmark 证据，自动给出 `MATCH`、`PARTIAL` 或 `MISMATCH`，并把缺失任务、错误推荐、catalog 缺口和 route 错误转成下一轮优化信号。

当前主流程 **不要求用户提交人工评测 JSON**。

## 当前工作流

```mermaid
flowchart LR
  A["Introduction + Method"] --> B["泄漏检查"]
  B --> C["能力与任务画像"]
  C --> D["Benchmark 检索与排序"]
  D --> E{"Catalog 覆盖情况"}
  E -->|完整| F["Direct Portfolio"]
  E -->|部分| G["Base Benchmark Adaptation"]
  E -->|缺失| H["New Benchmark Synthesis"]
  F --> I["封存 matcher 输出"]
  G --> I
  H --> I
  I --> J["读取论文 benchmark 证据"]
  J --> K["自动 MATCH / PARTIAL / MISMATCH"]
  K --> L["结构化错误反馈"]
  L --> M["通用规则优化"]
  M --> N["下一组 fresh holdout"]
```

### 隔离边界

- matcher 输入只包含 `introduction`、`method` 和可选 `constraints`；
- matcher 临时目录只包含 `autobench/`、公开 catalog、单个匿名 case 和输出目录；
- source identity、Experiment、benchmark gold 不复制到 worker；
- 自动核对在 worker 退出后运行；
- `fresh_holdout` 是泛化证据，`feedback_regression` 只证明已揭示论文上的修复有效，不作为新论文泛化结论。

## 快速开始

### 1. 只生成 benchmark 计划

```bash
python3 -m autobench match \
  --input assets/input/blind_cases/case_001.json \
  --catalog configs/benchmark_catalog.json \
  --output assets/output/example_match
```

输出：

- `benchmark_plan.json`：完整画像、候选分数、portfolio、route 与 provenance；
- `benchmark_plan.md`：可读报告；
- `automatic_review_input.json`：后匹配自动论文核对契约，`human_submission_required=false`。

### 2. 执行匹配、route 与数据合成

```bash
python3 -m autobench run \
  --input assets/input/workflow_demo/base_adaptation.json \
  --output assets/output/example_run \
  --base-records assets/input/workflow_demo/base_records.jsonl \
  --source-benchmark local_demo_base \
  --source-split train \
  --transformation interaction_wrapper \
  --transformation compositional_recombination \
  --transformation counterfactual_perturbation
```

该命令执行泄漏检查、画像、排序、route、可选 synthesis、逐条 expected-output 验证，并写出 `workflow_manifest.json`。若新任务需要 base records 但未提供，manifest 状态为 `BASE_RECORDS_REQUIRED`，CLI 退出码为 `2`。

### 3. 对一组论文进行盲测和自动论文核对

```bash
python3 step2_run_blind_matching.py \
  --cases-dir assets/input/fresh_holdout_suite_003/cases \
  --case-pattern 'fresh3_*.json' \
  --output-dir assets/output/fresh_holdout_suite_003/blind_runs

python3 step3_evaluate_blind_results.py \
  --runs-dir assets/output/fresh_holdout_suite_003/blind_runs \
  --gold-dir assets/input/fresh_holdout_suite_003/gold \
  --matcher-cases-dir assets/input/fresh_holdout_suite_003/cases \
  --output assets/output/fresh_holdout_suite_003/evaluation.json \
  --report assets/output/fresh_holdout_suite_003/evaluation.md \
  --minimum-cases 5

python3 -m autobench auto-review \
  --evaluation assets/output/fresh_holdout_suite_003/evaluation.json \
  --output-json assets/output/automatic_literature_review/fresh_holdout_suite_003.json \
  --output-markdown assets/output/automatic_literature_review/fresh_holdout_suite_003.md \
  --evidence-class fresh_holdout
```

`step3_evaluate_blind_results.py` 在严格数值门槛未过时返回退出码 `1`，但仍会完整写出 evaluation。自动论文核对随后读取该 evaluation 中的 source-paper 证据并输出逐论文错误类型。

### 4. 查看仓库完成状态

```bash
python3 step15_audit_completion.py
```

当前状态写入：

- `assets/output/end_to_end_demo/completion_audit.json`
- `assets/output/end_to_end_demo/completion_audit.md`

## 三类 route

| Route | 触发条件 | 输出 |
|---|---|---|
| `direct_portfolio` | catalog 覆盖全部显式任务 | 直接选择多个 benchmark |
| `base_benchmark_adaptation` | 只覆盖部分任务或存在可复用基础 benchmark | 推荐基础组合并生成 adaptation/synthesis 计划 |
| `new_benchmark_synthesis` | 没有可复用任务覆盖 | 生成新 benchmark 的 schema、指标和数据需求 |

合成数据只接受明确的 train/development source split。test、hidden 和 holdout split 会被拒绝。每条 draft 都保留 source record ID、source split、变换方式和 expected output，并由 deterministic verifier 复核。

## 自动论文核对判定

| 决策 | 含义 |
|---|---|
| `MATCH` | 盲协议通过；论文使用的已建模 benchmark 被覆盖；catalog 外任务族被正确识别；route 正确；没有额外错误推荐 |
| `PARTIAL` | 至少恢复了一部分论文评测构造，但仍有 benchmark、任务族、precision 或 route 缺口 |
| `MISMATCH` | 没有恢复有效论文评测构造，或盲协议失败 |

错误类型包括：

- `BLIND_PROTOCOL_FAILURE`
- `CATALOG_GAP`
- `UNMODELED_TASK_INFERENCE_GAP`
- `PORTFOLIO_RECALL_GAP`
- `PORTFOLIO_PRECISION_GAP`
- `ROUTE_ERROR`

其中 `CATALOG_GAP` 单独出现时，只表示论文 benchmark 尚未进入 catalog；若方法文本已经推断出正确任务族，仍可得到 `MATCH`。

## 当前结果

| Suite | Evidence class | Recall@5 | Recall@6 | Route accuracy | 自动核对 MATCH / PARTIAL / MISMATCH |
|---|---|---:|---:|---:|---:|
| Suite 001 baseline | fresh holdout | 0.5000 | 0.5000 | 0.2000 | 0 / 1 / 4 |
| Suite 001 feedback v1 | feedback regression | 0.9000 | 0.9000 | 1.0000 | 3 / 2 / 0 |
| Suite 002 baseline | fresh holdout | 0.9333 | 0.9333 | 0.0000 | 0 / 2 / 3 |
| Suite 002 feedback v2 | feedback regression | 0.9333 | 0.9333 | 1.0000 | 4 / 1 / 0 |
| Suite 003 baseline | fresh holdout | 0.6333 | 0.7333 | 0.4000 | 0 / 4 / 1 |
| Suite 003 feedback v3 | feedback regression | 1.0000 | 1.0000 | 1.0000 | 3 / 2 / 0 |

权威状态仍由最新 **fresh** 结果决定。因此当前 completion status 为 `AUTOMATED_LITERATURE_VALIDATION_NEEDS_ITERATION`。Suite 003 v3 说明修复在已揭示论文上有效，但不能替代下一套未见论文测试。

Suite 003 使用的五篇论文是：

- [Toolformer](https://arxiv.org/abs/2302.04761)
- [ProgPrompt](https://arxiv.org/abs/2209.11302)
- [Visual Programming](https://arxiv.org/abs/2211.11559)
- [Program of Thoughts](https://arxiv.org/abs/2211.12588)
- [Tree of Thoughts](https://arxiv.org/abs/2305.10601)

Suite 003 baseline 的逐论文判定是 `0 MATCH / 4 PARTIAL / 1 MISMATCH`；v3 feedback regression 是 `3 MATCH / 2 PARTIAL / 0 MISMATCH`。剩余两个 `PARTIAL` 分别对应：Toolformer 的具体数学 benchmark 选择不可由 Introduction/Method 唯一确定，以及 ProgPrompt 的 VirtualHome 与通用 household benchmark 之间仍有环境粒度差异。

## 主要目录

- `autobench/`：画像、检索、匹配、合成、自动核对与 CLI；
- `configs/benchmark_catalog.json`：论文来源可追踪的 benchmark catalog；
- `assets/input/fresh_holdout_suite_003/`：matcher-visible cases、冻结记录与 post-run gold；
- `assets/output/automatic_literature_review/`：自动论文核对 JSON/Markdown；
- `assets/output/end_to_end_demo/`：route demo 与 completion audit；
- `docs/README.md`：代码、实验轮次、失败原因与接手说明；
- `tests/test_autobench.py`：当前 44 项回归测试和历史兼容性测试。

## 历史人工评测模块

`autobench/literature_audit.py`、`autobench/review_gate.py`、`autobench/review_workflow.py`、`step5_prepare_human_review.py` 和 `step6_finalize_literature_audit.py` 仅用于读取和复现旧实验记录。当前 `match`、`run`、`auto-review` 与 completion audit 均不调用这些模块，也不会等待用户提交评测文件。

## 下一轮自动优化规则

1. 在查看论文实验章节前冻结 matcher 文件清单和 suite 选择；
2. 仅根据 title/abstract 选择下一组论文；
3. worker 只接收匿名 Introduction/Method；
4. worker 全部退出后再抽取 Experiment benchmark 证据；
5. 运行自动核对并保存 fresh baseline；
6. 只有 fresh baseline 全部 `MATCH`，且 source evidence 与 blind checks 全部通过，才将 completion status 置为 `COMPLETE`；
7. 若存在 `PARTIAL` 或 `MISMATCH`，生成通用错误类型、修改规则、记录 feedback regression，再进入新的 fresh suite。
